class LuciferMoringstar(object):

    DEFAULT_MSG = """👋Hello {mention}.....!!!\nIt's Power Full [{bot_name}](t.me/{bot_username}) Here 😎\nAdd Me To Your Group And Make Sure I'm an Admin There! \nAnd Enjoy My Pever Show.....!!!🤪"""

    HELP_MSG = """**You can contact me @howtodoyt**"""

    ABOUT_MSG = """
🤖 My Name [{bot_name}](t.me/{bot_username})

🧑 My Dev : [HOWTODO](t.me/howtodoyt)

🧑 My Creator : {dev_name}

📦 My Source : [Click Here](https://github.com/bossstory/LuciferMoringstar-Robot)

📺 My Youtube : [Ckick Here](https://www.youtube.com/channel/UCohk_mpuW8SpgZMyOzRdKcA)

🏷️ My Updates : [HOW TO DO](t.me/HTDGROUPFORMOVIES)

🗣️ My Support : [Any Doubt](t.me/howtodoyt)"""

    FILE_CAPTIONS = """Hello 👋 {mention}\n\n📁Title {title}\n\n🔘Size {size}"""

    PR0FESS0R_99 = """
**ADMINS COMMANDS**

 » /broadcast - Reply Any Media Or Message
 » /delete - Reply Files
 » /deleteall - Delete All Files
 » /total - How Many Files Saved
 » /logger - Get Bot Logs
 » /channel - Add Channel List"""

    ADD_YOUR_GROUP = """**__You can add me any Group to search Movies__**"""
    SPELL_CHECK = """
Hello 👋〘 {mention} 〙,

Couldn't Find {query}?  Please Click Your Request Movie Name"""
    GET_MOVIE_1 = """
📽️ Requested Movie : [{query}]({url})
👤 Requested By : {mention}
🎬 Title : [{title}]({url})
📆 Year : {year}
🌟 Rating {rating}/10
🗨️ Genres {genres}"""


    GET_MOVIE_2 = """
📽️ Requested Movie : {query}
👤 Requested By : {mention}

© **{chat}**"""
